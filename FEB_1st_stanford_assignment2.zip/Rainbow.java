/*
 * File: Rainbow.java
 * Name: 
 * Section Leader: 
 * -----------------
 * This file is the starter file for the Rainbow problem.
 */

import java.awt.Color;

import acm.graphics.*;
import acm.program.*;

public class Rainbow extends GraphicsProgram {	
	public void run() {
		//Color[] color= new Color(){red, orange, yellow, green, blue, violet};
		//Color[] color_arr = {white};
		
		for(int layer = 0; layer < 7; layer++)
		{
			GOval circle = new GOval(-125,layer* 20,1000,700);
			circle.setFillColor(Color.BLUE);
			add(circle);

		}
	
	}
}
