/*
 * File: GraphicsHierarchy.java
 * Name: 
 * Section Leader: 
 * ----------------------------
 * This file is the starter file for the GraphicsHierarchy problem.
 */

import acm.graphics.*;
import acm.program.*;

public class GraphicsHierarchy extends GraphicsProgram {	
	public void run() {
		
	//window size
	final int window_width = 800;
	final int window_height = 600;
	
	this.setSize(window_width, window_height);

	//box size 
	final int box_width = 150;
	final int box_height = 45;
	
	//GObject box position 
	final double x_GObject = (window_width - box_width) / 2;
	final double y_GObject = 30;
	
	
	//following subclass box position 
	final int interval = 10; // interval between boxes
	final int y_subclass_box = 300;
	int[] x_sub_class_box = {0,10,0,0,0};
	for(int i = 2; i< 5; i++)
	{
		x_sub_class_box[i] = box_width * (i - 1)+ interval * 2;
	}

	//boxes
	
	GObject box = new GRect(box_width, box_height);
	GObject[] box_arr = new GRect[5];
	
	for(int i = 0; i < 5; i++)
		box_arr[i] = box;
	
	GObject box_GObject = new GRect(box_width, box_height);
	GObject box_GLabel  = new GRect(box_width, box_height);
	GObject box_GLine   = new GRect(box_width, box_height);
	GObject box_GOval   = new GRect(box_width, box_height);
	GObject box_GRect   = new GRect(box_width, box_height);

	//labels
	GObject label_GObject = new GLabel("GObject");
	GObject label_GLabel  = new GLabel("GLabel");
	GObject label_GLine   = new GLabel("GLine");
	GObject label_GOval   = new GLabel("GOval");
	GObject label_GRect   = new GLabel("GRect");

	//lines
	
	
	
	//label position
		//1. GObject
	double x_label_GObject = x_GObject + box_width / 2 - label_GObject.getWidth() / 2;
	double y_label_GObject = y_GObject + (box_height / 2) + label_GObject.getHeight() / 2;
		//2. GLabel
	
	
	add(box_GObject,x_GObject, y_GObject);
	add(label_GObject,x_label_GObject, y_label_GObject);
	
	for(int i = 2; i< 5; i++)
		add(box_GLabel,x_subclass_box1, y_subclass_box1);

	
	}
}

